#ifndef _ARDUINO_SECRETS_H_
#define _ARDUINO_SECRETS_H_
#define SECRET_SSID "WIFI-CIE-UNAM-101"                           //"WIFI-IOT-NB"             //IER                // WIFI-IOT-NB
#define SECRET_PASS ""                                            //7vHOej1tqKVKZn82          //acadier2014        //7vHOej1tqKVKZn82

#ifdef _ARDUINO_MQTT_CLIENT_H_
#define SECRET_BROKER "tb.ier.unam.mx"
#define SECRET_PORT 1883                                          //puerto del server
#define SECRET_DEVID "29e206c0-0ad3-11ee-a64c-031ad2021d0e"       //"1fa917c0-aae9-11ec-897a-cd1c177f68f0"        //1fa917c0-aae9-11ec-897a-cd1c177f68f0
#define SECRET_TOKEN "H4qcoZ6XK2XfJmC7du3W"                       //"283aV76r6z4CIccCw6cC"                        // sis evaporativo 2jfbJUg55iexWkPkEDPT
#define SECRET_TOPIC "v1/devices/me/telemetry"
#endif

#ifdef ArduinoHttpClient_h
#define SECRET_SERVER "tb.ier.unam.mx" 
#define SECRET_PORT 8080                                          //puerto del server
#define SECRET_TOPIC "/api/v1/H4qcoZ6XK2XfJmC7du3W/telemetry"
#endif

#endif
