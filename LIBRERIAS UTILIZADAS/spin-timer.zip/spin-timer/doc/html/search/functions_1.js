var searchData=
[
  ['cancel_136',['cancel',['../class_spin_timer.html#a4a6d0514b592f1f1cf9a2a86d9f6b615',1,'SpinTimer']]],
  ['cmake_5fminimum_5frequired_137',['cmake_minimum_required',['../_c_make_lists_8txt.html#acf5563f57aea1ed17d0a9f7efd0b88a8',1,'cmake_minimum_required(VERSION 3.16 FATAL_ERROR) set(PROJECT &quot;SpinTimer&quot;) project($:&#160;CMakeLists.txt'],['../_examples_2_simple_counter_2_c_make_lists_8txt.html#a47bb94f17289c2ad1c89af45893cda59',1,'cmake_minimum_required(VERSION 3.16 FATAL_ERROR) set(PROJECT &quot;SimpleCounter&quot;) project($:&#160;CMakeLists.txt'],['../tests_2_c_make_lists_8txt.html#adbe63c740b2a9ed10664084961449f89',1,'cmake_minimum_required(VERSION 3.16) set(PROJECT spin-timer-test) project($:&#160;CMakeLists.txt']]]
];
