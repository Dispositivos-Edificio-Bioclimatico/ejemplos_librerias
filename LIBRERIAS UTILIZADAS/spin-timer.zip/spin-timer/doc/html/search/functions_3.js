var searchData=
[
  ['getinterval_140',['getInterval',['../class_spin_timer.html#a950f9e3e2631598351c124e9a1b1a09d',1,'SpinTimer']]]
];
