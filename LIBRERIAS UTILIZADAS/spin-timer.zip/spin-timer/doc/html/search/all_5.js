var searchData=
[
  ['include_23',['include',['../tests_2_c_make_lists_8txt.html#add1f16e08992a496ae917619a8b887ed',1,'CMakeLists.txt']]],
  ['incrementtmillis_24',['incrementTMillis',['../class_mock___uptime_info.html#a6e01b78a1f3ab4fa5502998cf06863c5',1,'Mock_UptimeInfo']]],
  ['info_5farch_25',['info_arch',['../_c_make_c_x_x_compiler_id_8cpp.html#a59647e99d304ed33b15cb284c27ed391',1,'CMakeCXXCompilerId.cpp']]],
  ['info_5fcompiler_26',['info_compiler',['../_c_make_c_x_x_compiler_id_8cpp.html#a4b0efeb7a5d59313986b3a0390f050f6',1,'CMakeCXXCompilerId.cpp']]],
  ['info_5flanguage_5fdialect_5fdefault_27',['info_language_dialect_default',['../_c_make_c_x_x_compiler_id_8cpp.html#a1ce162bad2fe6966ac8b33cc19e120b8',1,'CMakeCXXCompilerId.cpp']]],
  ['info_5fplatform_28',['info_platform',['../_c_make_c_x_x_compiler_id_8cpp.html#a2321403dee54ee23f0c2fa849c60f7d4',1,'CMakeCXXCompilerId.cpp']]],
  ['instance_29',['instance',['../class_spin_timer_context.html#aa00434d24de7d35ef45f6789f19b3ab8',1,'SpinTimerContext::instance()'],['../class_uptime_info.html#a6978a042bec2689d1e80d0de87237602',1,'UptimeInfo::Instance()']]],
  ['instantiate_5ftest_5fcase_5fp_30',['INSTANTIATE_TEST_CASE_P',['../_test___spin_timer_8cpp.html#a995a1fe580eda2aaefbcf29e7a77f365',1,'INSTANTIATE_TEST_CASE_P(SpinTimer, SpinTimerSingleShot, ::testing::Values(std::make_tuple(10, 0), std::make_tuple(10, ULONG_MAX), std::make_tuple(10, ULONG_MAX - 1), std::make_tuple(10, ULONG_MAX - 10), std::make_tuple(10, ULONG_MAX - 10+1), std::make_tuple(0, 0), std::make_tuple(0, ULONG_MAX), std::make_tuple(0, ULONG_MAX - 1), std::make_tuple(0, ULONG_MAX - 0), std::make_tuple(0, ULONG_MAX - 0+1))):&#160;Test_SpinTimer.cpp'],['../_test___spin_timer_8cpp.html#a8a6de03b9044240ef6260438bd39d63e',1,'INSTANTIATE_TEST_CASE_P(SpinTimer, SpinTimerRecurring, ::testing::Values(SpinTimerRecurringTestParam(10, 0, 1), SpinTimerRecurringTestParam(10, 0, 10), SpinTimerRecurringTestParam(10, 0, 100), SpinTimerRecurringTestParam(10, ULONG_MAX, 500), SpinTimerRecurringTestParam(10, ULONG_MAX-1, 500))):&#160;Test_SpinTimer.cpp']]],
  ['is_5fautostart_31',['IS_AUTOSTART',['../class_spin_timer.html#ac570d02425586d9dd416b83fb5d8abf7',1,'SpinTimer']]],
  ['is_5fnon_5fautostart_32',['IS_NON_AUTOSTART',['../class_spin_timer.html#a909cefeceaa9679228e6f96b3f03d9c2',1,'SpinTimer']]],
  ['is_5fnon_5frecurring_33',['IS_NON_RECURRING',['../class_spin_timer.html#a40c35f6f0e3e377ffdcbb40ce95a0c7d',1,'SpinTimer']]],
  ['is_5frecurring_34',['IS_RECURRING',['../class_spin_timer.html#ad930594243c1fa87666827f7f4823c73',1,'SpinTimer']]],
  ['isexpired_35',['isExpired',['../class_spin_timer.html#a98522222b5fdaf2609164d55dfcf1001',1,'SpinTimer']]],
  ['isrunning_36',['isRunning',['../class_spin_timer.html#a74e21666ec8e2cfd880117a5b39c74f9',1,'SpinTimer']]]
];
