var struct_spin_timer_recurring_test_param =
[
    [ "SpinTimerRecurringTestParam", "struct_spin_timer_recurring_test_param.html#aebb1a96a34edfa91a050e09a5db57b33", null ],
    [ "delayMillis", "struct_spin_timer_recurring_test_param.html#aaf1b26a833befcbfd3fc6590d61444ae", null ],
    [ "numOfLoops", "struct_spin_timer_recurring_test_param.html#a07f508c9196a8f6d6f4363cf6b724079", null ],
    [ "startMillis", "struct_spin_timer_recurring_test_param.html#a60e9c96717bfef8d4f952b88112a7b9d", null ]
];