var indexSectionsWithContent =
{
  0: "acdghikmnprstu~",
  1: "dmrsu",
  2: "ckmrstu",
  3: "acdghimnrstu~",
  4: "dinst",
  5: "s",
  6: "s",
  7: "acdhps",
  8: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Macros",
  8: "Pages"
};

