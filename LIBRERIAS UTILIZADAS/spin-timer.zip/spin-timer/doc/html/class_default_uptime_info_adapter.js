var class_default_uptime_info_adapter =
[
    [ "tMillis", "class_default_uptime_info_adapter.html#ac18261c849d90349273a70a0e21b1294", null ]
];