var class_uptime_info_adapter =
[
    [ "UptimeInfoAdapter", "class_uptime_info_adapter.html#a38f682884b67e40f4558b8a731551048", null ],
    [ "~UptimeInfoAdapter", "class_uptime_info_adapter.html#a722b66d99921df95d5a7a4b795f87221", null ],
    [ "tMillis", "class_uptime_info_adapter.html#aae9600b84a90067106eb0cb624094153", null ]
];